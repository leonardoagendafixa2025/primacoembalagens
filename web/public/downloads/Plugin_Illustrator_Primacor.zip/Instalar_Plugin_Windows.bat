@echo off
chcp 65001 >nul
title Instalador Oficial - Plugin PRIMACOR EMBALAGENS para Adobe Illustrator
color 0A

echo =====================================================================
echo    INSTALADOR OFICIAL: PRIMACOR EMBALAGENS - ADOBE ILLUSTRATOR
echo =====================================================================
echo.
echo 1. Habilitando modo de desenvolvedor de extensoes no registro...

reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.7" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.8" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.15" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.16" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.17" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.18" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo    [OK] Modo de desenvolvedor ativado com sucesso.
echo.
echo 2. Verificando se o Adobe Illustrator esta aberto...

tasklist /FI "IMAGENAME eq Illustrator.exe" 2>NUL | find /I /N "Illustrator.exe">NUL
if "%ERRORLEVEL%"=="0" (
    echo.
    echo    [ATENCAO] O Adobe Illustrator esta aberto no momento!
    echo    Por favor, FECHE O ILLUSTRATOR e depois pressione qualquer tecla
    echo    para prosseguir com a instalacao/atualizacao limpa...
    echo.
    pause >nul
)

echo 3. Instalando/Atualizando arquivos do plugin na pasta oficial da Adobe...

set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.primacor.plmpacklib"

if exist "%TARGET_DIR%" (
    echo    Removendo versao anterior para instalacao limpa...
    rd /s /q "%TARGET_DIR%" >nul 2>&1
)

mkdir "%TARGET_DIR%" >nul 2>&1

xcopy /E /Y /I "%~dp0com.primacor.plmpacklib\*" "%TARGET_DIR%\" >nul

if exist "%LOCALAPPDATA%\Adobe\CEP\cache" (
    del /f /q "%LOCALAPPDATA%\Adobe\CEP\cache\com.primacor.plmpacklib*" >nul 2>&1
)

if %ERRORLEVEL% equ 0 (
    echo    [OK] Arquivos instalados e atualizados com sucesso em:
    echo         %TARGET_DIR%
    echo.
    echo =====================================================================
    echo    INSTALACAO / ATUALIZACAO CONCLUIDA COM SUCESSO!
    echo =====================================================================
    echo.
    echo Como usar:
    echo 1. Abra o Adobe Illustrator.
    echo 2. Acesse o menu superior:
    echo    Janela (Window) ^> Extensoes (Extensions) ^> PRIMACOR EMBALAGENS.
    echo 3. O estúdio 3D com sincronizacao de facas e artes abrira no Illustrator!
    echo.
) else (
    echo    [ERRO] Falha ao copiar arquivos. Verifique permissoes de usuario.
)

echo.
pause