﻿#!/bin/bash
echo "====================================================================="
echo "   INSTALADOR OFICIAL: PRIMACOR EMBALAGENS - ADOBE ILLUSTRATOR (MAC)"
echo "====================================================================="
echo ""

for v in 7 8 9 10 11 12 13 14 15 16 17 18; do
  defaults write com.adobe.CSXS.$v PlayerDebugMode 1 2>/dev/null
done

TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/com.primacor.plmpacklib"
rm -rf "$TARGET_DIR" 2>/dev/null
mkdir -p "$TARGET_DIR"

DIR="$( cd "$( dirname """" )" && pwd )"
cp -R "$DIR/com.primacor.plmpacklib/"* "$TARGET_DIR/"

echo "[OK] Plugin instalado/atualizado com sucesso em:"
echo "     $TARGET_DIR"
echo ""
echo "Como usar:"
echo "1. Abra (ou reinicie) o Adobe Illustrator."
echo "2. Acesse: Janela (Window) > Extensoes (Extensions) > PRIMACOR EMBALAGENS."
echo ""
read -p "Pressione Enter para fechar..."